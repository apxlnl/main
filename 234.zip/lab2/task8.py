phone = "+38(099)-123-12-13"
print(phone.replace("+", "").replace("(", "").replace(")", "").replace("-", "").replace(" ", ""))