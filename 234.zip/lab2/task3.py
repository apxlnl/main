sentence = input("Введіть речення: ")
print(sentence.strip().count(' ') + 1)