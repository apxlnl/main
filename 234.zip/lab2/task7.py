filename = 'example.txt'
print(filename.startswith('example'))