num1 = float(input("Введіть перше число: "))
num2 = float(input("Введіть друге число: "))
num3 = float(input("Введіть третє число: "))

print(f"{num1:,.2f}".rstrip('0').rstrip('.'))
print(f"{num2:,.2f}".rstrip('0').rstrip('.'))
print(f"{num3:,.2f}".rstrip('0').rstrip('.'))