value = 0.254
print(f"Відсоткове значення: {value:.2%}")