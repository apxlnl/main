text_pass = "hhh lll hhh ddd sss"
user_pass = input("Введіть пароль: ")
if user_pass in text_pass.split():
    print("Пароль знайдено.")
else:
    print("Пароль не знайдено.")