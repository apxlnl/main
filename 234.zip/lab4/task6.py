amount = float(input("Введіть суму покупки: "))
if amount <= 1000:
    discount = 0
elif amount <= 5000:
    discount = 0.10
elif amount <= 10000:
    discount = 0.20
else:
    discount = 0.30

final_amount = amount * (1 - discount)
print(f"Сума до сплати: {final_amount:.2f}")