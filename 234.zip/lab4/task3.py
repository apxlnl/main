score = int(input("Введіть вашу оцінку: "))
if score >= 90:
    print("Ваша оцінка A")
elif score >= 82:
    print("Ваша оцінка B")
elif score >= 74:
    print("Ваша оцінка C")
elif score >= 64:
    print("Ваша оцінка D")
elif score >= 60:
    print("Ваша оцінка E")
elif score >= 35:
    print("Ваша оцінка FX")
else:
    print("Ваша оцінка F")