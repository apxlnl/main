a = float(input("Введіть число a: "))
b = float(input("Введіть число b: "))
if a < b:
    print(f"Найменше число: {a}")
else:
    print(f"Найменше число: {b}")