balance = 1000.0

print("Ласкаво просимо до банкомату!")
print("Виберіть дію:")
print("1. Перевірити баланс")
print("2. Внести гроші")
print("3. Зняти гроші")
print("4. Вихід")

choice = input("Ваш вибір (1-4): ")

if choice == "1":
    print(f"Ваш поточний баланс: {balance:.2f} грн")
elif choice == "2":
    deposit = float(input("Введіть суму для внесення: "))
    if deposit > 0:
        balance += deposit
        print(f"Успішно внесено. Новий баланс: {balance:.2f} грн")
    else:
        print("Сума внеску повинна бути більше 0.")
elif choice == "3":
    withdraw = float(input("Введіть суму для зняття: "))
    if withdraw <= 0:
        print("Сума зняття повинна бути більше 0.")
    elif withdraw > balance:
        print("Недостатньо коштів на рахунку.")
    else:
        balance -= withdraw
        print(f"Успішно знято. Залишок на рахунку: {balance:.2f} грн")
elif choice == "4":
    print("Дякуємо за користування банкоматом. До побачення!")
else:
    print("Невірно обрана дія.")