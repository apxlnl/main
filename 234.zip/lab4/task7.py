age = int(input("Введіть ваш вік: "))
if age < 18:
    print("Ви вважаєтеся Здоровим.")
else:
    diseases = input("Чи є у вас супутні захворювання (так/ні)? ").strip().lower() == "так"
    smoking = input("Чи палите ви (так/ні)? ").strip().lower() == "так"
    alcohol = input("Чи вживаєте алкоголь (так/ні)? ").strip().lower() == "так"
    
    if diseases or smoking or alcohol:
        print("Ви вважаєтеся в зоні ризику.")
    else:
        print("Ви вважаєтеся Здоровим.")